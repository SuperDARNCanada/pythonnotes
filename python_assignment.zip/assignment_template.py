import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

speed_of_light = 3.0e8 #units : m/s

class Acf(object):
    """This class contains the methods to simulate and fit a simple ACF"""
    def __init__(self, pulse_seq, pulse_increment, vel, width, freq, lag0_pwr):
        #I've helped you out by filling out the constructor. These parameters
        #will create and process your ACF at instantiation. You can call your
        #fitting and plotting from the main() function.

        lags = self.create_lags(pulse_seq)

        self.wave_len = speed_of_light / freq
        #self.t = np.array(lags) * pulse_increment #uncomment once lags are made
        self.acf = self.simulate_acf(vel, width, lag0_pwr)
        self.acf_mag = self.acf_magnitude(self.acf)
        self.acf_phase_unwrapped = self.acf_phase_unwrapped(self.acf)
        self.acf_ln_pwr = self.acf_log_pwr(self.acf_mag)

    def create_lags(self,pulse_seq):
        """Calculate the lags in the pulse sequence.These lags are the
        lags that are used to estimate the ACF"""

        #TODO: return a list of lags created from a pulse sequence

        pass


    def simulate_acf(self,vel, width, lag0_pwr):
        """Simulates and returns an ACF using a decaying exponential"""

        #TODO: return a simulated ACF
        pass


    def acf_magnitude(self,acf):
        """Return the magnitude of the ACF"""

        #TODO: return the magnitude of each ACF point
        pass


    def acf_log_pwr(self,acf_mag):
        """Returns the natural log of the ACF magnitude"""

        #TODO: return the natural log of each ACF magnitude point
        pass


    def acf_phase_unwrapped(self,acf):
        """Returns the phase of the ACF. The phase needs to be unwrapped in order to
        use linear fitting. We use a simple unwrap function for a first order unwrap"""

        #TODO: Find the phase of each ACF point and then unwrap it.
        #return the result.
        pass

    def fit_velocity_and_err(self):
        """We fit to our unwrapped phase and then convert to velocity. The
        velocity and error is returned. The fit result is also being returned
        so that we can plot our slope along with the phase"""

        #TODO: Fit to phase, convert to velocity and return results
        pass

    def fit_power_and_error(self):
        """We fit to our log power and then convert to dB. The
        power and error is returned. The fit result is also being returned
        so that we can plot our slope along with the power"""

        #TODO: Fit to power, convert to dB and return results

        pass
    def plot_acf(self):
        """Plot the ACF real and imaginary parts in a new window"""

        #TODO: Create a new figure for the plot
        pass

    def plot_acf_magnitude(self):
        """Plot the ACF magnitude in a new window"""

        #TODO: Create a new figure for the plot
        pass

    def plot_acf_phase(self,fitted_result=None):
        """Plot the ACF phase in a new window. If a fitted result
        is supplied, we should plot the best fit line as well"""

        #TODO: Create a new figure for the plot. fitted_result is defaulted
        #to None. If not None, plot the best fit line.
        pass

    def plot_acf_ln_pwr(self,fitted_result=None):
        """Plot the log of the ACF power in a new window. If a fitted result
        is supplied, we should plot the best fit line as well."""

        #TODO: Create a new figure for the plot. fitted_result is defaulted
        #to None. If not None, plot the best fit line.
        pass

def main():
    pulse_seq = [0,14,22,24,27,31,42,43]
    pulse_increment = 1500e-6 #units : s
    vel = 300 #units : m/s
    width = 90 #units : m/s
    freq = 12e6 #units : Hz
    lag0_pwr = 1.0 #units : arbitrary

    new_acf = Acf(pulse_seq, pulse_increment, vel, width, freq, lag0_pwr)

    #TODO: Call your fitting and plotting functions. Print results to console.

    #We make a single call to plt.show() at the end so that all of
    #our plots show up at once.
    plt.show()

if __name__ == '__main__':
    main()